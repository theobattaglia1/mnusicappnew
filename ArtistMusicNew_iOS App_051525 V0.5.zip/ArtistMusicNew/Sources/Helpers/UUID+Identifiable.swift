import Foundation
extension UUID: Identifiable {
    public var id: UUID { self }
}
